# -*- coding: utf-8 -*- 
from flask import Flask,url_for,render_template,request

import sys
reload(sys)
sys.setdefaultencoding('utf8')
import read
import job

app = Flask(__name__)

@app.route('/')
def hello_world():
    return 'Hello Flask!'

@app.route('/hello/')
@app.route('/hello/<name>')
def hello(name=None):
    return render_template('hello.html', name=name)

@app.route('/login', methods=['POST', 'GET'])
def login():
    error = "Invalid!!!"
    if request.method == 'POST':
        if valid_login(request.form['username'],
                       request.form['password']):
            return log_the_user_in(request.form['username'])
        else:
            error = 'Invalid username/password'
    # the code below is executed if the request method
    # was GET or the credentials were invalid
    return render_template('login.html', error=error)

def log_the_user_in(result):
   return render_template('login.html',result=result) 

def valid_login(a,b):
    if a and b:
        return True
    else:
        return False


@app.route('/job', methods=['POST', 'GET'])
def job_page():
    if request.method == 'POST':
        return get_result(request.form['job_id'].strip(),request.form['dependency_depth'],request.form['flow_length'])

    return render_template('job.html')

def get_result(job_id,dependency_depth,flow_length):

    result=""
    if not job_id.isdigit() or len(job_id) > 4 :
        result="job_id is not valid.Please check!!!"
        return render_template('job.html',result=result) 

    result = job.get_job_relation(job_id,dependency_depth,flow_length)

    return render_template('job.html',job_id=job_id,dependency_depth=dependency_depth,flow_length=flow_length,result=result) 

#def get_job_relation(job_id,dependency_depth,flow_length):
#    return job_id+dependency_depth+flow_length


if __name__ == '__main__':
   
    print "start\n" 
    
    #read.graph_init()

    app.debug = True 
    app.run(host='0.0.0.0')
    print "end"

