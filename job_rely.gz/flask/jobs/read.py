# -*- coding: utf-8 -*- 
import pandas as pd 
import shlex
import re 
import networkx as nx 
import matplotlib.pyplot as plt 
import datetime
import pickle

#根据CON列的读取出依赖关系为字典
def fa(x):
    return dict(sorted(i.replace('(','_').split(',')[:2]) for i in re.findall(r'AFTER_(.*?)\)',x))

def graph_init():

    today = str(datetime.date.today() )

    data = pd.DataFrame(columns=['jobID','a','b','c','d','END','e','f','CON','g'])
    with open('job_info/tbl_sch_schedule_info.del') as f:

        index = 0
        for i in f.readlines():
            index += 1
            if index==1:
                continue
            #因为有一列括号中也有逗号，所以正常的strip().split()会出错，所以这里用shlex模块处理文件的每一行,posix=True会忽略括号和引号中的逗号
            ss=shlex.shlex(i,posix=True)
            ss.whitespace=' '
            ss.whitesapce_split=True
            ss = list(ss)
            for j in ss:
                if j in [',','\n']:
                    ss.remove(j)
            data.loc[index] = ss
            #line = i.strip().split(',')
            #line = [j.strip(' ').strip('"') for j in line]
            
    data = data[data['END']=='99991231'].drop(['a','b','c','d','e','f','g','END'],axis=1)
    #print data.shape

    data['job_rely'] = data.CON.apply(fa)

    #去除自身依赖
    for i in range(len(data)):
        if data.iloc[i,2]:
            try:
                data.iloc[i,2].pop(str(data.iloc[i,0]))
            except KeyError:
                pass
    #去除空字典			
    data = data[data['job_rely']!={}]	

    #定义有向图的节点和边		
    nodes = list(data['jobID'])
    co = {'SUCC_0':'red','SUCC_-1':'red','ALL_0':'green','ALL_-1':'green'}
    edges = [(j,data.iloc[i,0].strip("'"),data.iloc[i,2][j]) for i in range(len(data)) for j in list(data.iloc[i,2].keys()) ]
    new_edges = [(edges[i][0],edges[i][1],dict([('color',co[edges[i][2]])])) for i in range(len(edges))]

    #生成有向图
    colors = [ 'green'] 
    #有向图 
    DG = nx.DiGraph() 
    #一次性添加多节点，输入的格式为列表 
    DG.add_nodes_from(nodes) 
    #添加边，数据格式为列表 
    DG.add_edges_from(new_edges) 

    #plt.figure(figsize=(50,50))
    #nx.draw(DG,with_labels=True, node_size=900, node_color = colors,style='dashdot',font_size=12) 
    #保存有向图和有向图的文件
    #plt.savefig("pic_job_%s.png" %today) 

    with open('job_networkx.pkl','wb')as f:
        pickle.dump(DG,f)
      
if __name__ == '__main__':

	graph_init()

