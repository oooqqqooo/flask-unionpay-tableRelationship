# -*- coding: utf-8 -*- 
import networkx as nx
import pickle
import matplotlib.pyplot as plt 
import tree

#解析依赖和流向的关系，生成嵌套字典，如{'no surfacing': {0: 'no', 1: {'flippers': {0: 'no', 1: 'yes'}}, 3: 'maybe'}}，用于绘制树状图;
def parse(dic):
    num=0;d=[]
    for i in range(len(dic)):
        temp2={}
        for key,value in dic[i].items():
            temp={}
            if len(value)>0:
                for l in value:
                    temp[num] = l
                    num += 1
                temp2[key]=temp
        d.append(temp2)
    for j in range(len(d)-2,-1,-1):
        for key,value in d[j].items():
            for ke,va in value.items():
                try:
                    if va in d[j+1]:
                        d[j][key][ke]=dict([(va,d[j+1][va])])
                except TypeError:
                    pass
                
    return d[0]

def job_info(job):
    with open('job_info/tbl_sch_function_info.del') as f:
        index = 0
        for i in f.readlines():
            index += 1 
            if index==1:
                continue
            line =[j.strip(' ').strip('"') for j in i.strip().split(',')[:4]]
            if line[0]== job:
                return str(job)+": "+line[3]+"/"+line[2]+'\n'

#向上寻找依赖关系
def forward(g,pred,father):
    newPred = [];dic={};pp=[]#pp 用于输出的顺序控制
    for i in pred:
        temp=[]
        for j in g.predecessors(i):
            if j not in father:
                father.append(j)
                newPred.append(j)
                temp.append(j)
        dic[i]=temp
        pp.append(temp)
    return father,newPred,dic,pred,pp

#向下查看流向
def backward(g,succ,child):
    newSucc = [];dic={};ss = []
    for i in succ:
        temp=[]
        for j in g.successors(i):
            if j not in child:
                child.append(j)
                newSucc.append(j)
                temp.append(j)
        dic[i]=temp
        ss.append(temp)
    return child,newSucc,dic,succ,ss

#根据传入的参数查看表或job的依赖和流向，并进行图展示
def sub_draw(g,table,for_deepth=1,back_deepth=0):
    # pred是table的所有的父辈，succ是table的所有子辈
    try:
        s = job_info(table)
    except Exception as e:
        s = ''
    pred =list(g.predecessors(table))
    succ = list(g.successors(table))
    for_deepth=int(for_deepth)
    back_deepth=int(back_deepth)
    #print type(pred)
    a = pred;b=succ   
    father = [i for i in pred];child = [i for i in succ]

    if for_deepth>0:
        dic_ff=[];dic_ff.append(dict([(table,pred)]))
        s = s + '\n第1辈的依赖（直接依赖）：\n'+str(table)+' <-- '+str(pred)+'\n'
        for i in range(for_deepth-1):
            if len(pred)>0:
                father,pred,dic_f,old_pred,pp = forward(g,pred,father)  #old_pred和pp用于输出顺序的控制
                if sum([len(k) for k in dic_f.values()])>0:  #没有依赖的字典中不一定为空，要判断字典中的value是不是都为空
                    s = s+'\n第'+str(i+2) +'辈的依赖：\n'
                de = []  #需要从字典中删除的元素
                for m in range(len(old_pred)):
                    if len(pp[m])>0:
                        s = s+str(old_pred[m])+'<--'+str(pp[m])+'\n'
                for key,value in dic_f.items():
                    if len(value)==0:
                        de.append(key)
                for d in de:
                    dic_f.pop(d)
                dic_ff.append(dic_f)
        s = s + '\n所有依赖：\n'+str(father)+'\n\n\n'
        
    if back_deepth>0:
        dic_bb=[];dic_bb.append(dict([(table,succ)]))  #dic_bb用于构建树状图的输入
        s = s +'第1代的流向（直接流向）：\n'+str(table)+' --> '+str(succ)+'\n'
        for j in range(back_deepth-1):
            if len(succ)>0:
                child,succ,dic_b,old_succ,ss = backward(g,succ,child)
                if sum([len(k) for k in dic_b.values()])>0:
                    s = s +'\n第'+str(j+2)+'代的流向：\n'
                de = []
                for m in range(len(old_succ)):
                    if len(ss[m])>0:
                        s = s+str(old_succ[m])+'<--'+str(ss[m])+'\n'
                for key,value in dic_b.items():
                    if len(value)==0:
                        de.append(key)
                for d in de:
                    dic_b.pop(d)
                dic_bb.append(dic_b)
        s = s +'\n所有流向：\n'+str(child) +'\n'
        
        pa_f = parse(dic_ff);pa_b = parse(dic_bb)

        if pa_f:
            tree.createPlot(pa_f, "%s_for_%d" % (table,for_deepth))
        if pa_b:
            tree.createPlot(pa_b, "%s_back_%d" % (table,back_deepth))

    return s 

def get_job_relation(job_id,for_deepth,back_deepth):
    with open('job_networkx.pkl','rb') as f:
        DG = pickle.load(f)

#    try:
#        plt.switch_backend('agg')
#        ret=sub_draw(DG,job_id,for_deepth,back_deepth)
#    except Exception as e:
#        ret=e

    plt.switch_backend('agg')
    ret=sub_draw(DG,job_id,for_deepth,back_deepth)

    return ret


if __name__ == '__main__':

	print get_job_relation('4656',5,3)

