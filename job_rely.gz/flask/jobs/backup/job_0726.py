# -*- coding: utf-8 -*- 
import networkx as nx
import pickle
import matplotlib.pyplot as plt 

#向上寻找依赖关系
def forward(g,pred,father):
    newPred = [];dic={}
    for i in pred:
        temp=[]
        for j in g.predecessors(i):
            if j not in father:
                father.append(j)
                newPred.append(j)
                temp.append(j)
        dic[i]=temp
    return father,newPred,dic

#向下查看流向
def backward(g,succ,child):
    newSucc = [];dic={}
    for i in succ:
        temp=[]
        for j in g.successors(i):
            if j not in child:
                child.append(j)
                newSucc.append(j)
                temp.append(j)
        dic[i]=temp
    return child,newSucc,dic

#根据传入的参数查看表或job的依赖和流向，并进行图展示
def sub_draw(g,table,for_deepth=1,back_deepth=0):
    # pred是table的所有的父辈，succ是table的所有子辈
    pred =list(g.predecessors(table))
    succ = list(g.successors(table))
    for_deepth=int(for_deepth)
    back_deepth=int(back_deepth)
    #print type(pred)
    a = pred;b=succ   
    father = [i for i in pred];child = [i for i in succ]
    if for_deepth>0:
        s = '第1辈的依赖（直接依赖）：\n'+str(table)+' <-- '+str(pred)+'\n'
        for i in range(for_deepth-1):
            if len(pred)>0:
                father,pred,dic_f = forward(g,pred,father)
                if sum([len(k) for k in dic_f.values()])>0:  #没有依赖的字典中不一定为空，要判断字典中的value是不是都为空
                    s = s+'\n第'+str(i+2) +'辈的依赖：\n'
                for key,value in dic_f.items():
                    if len(value)>0:
                        s = s + str(key)+' <-- '+str(value)+'\n'
        s = s + '\n所有依赖：\n'+str(father)+'\n\n\n'
    if back_deepth>0:
        dic=[];dic.append(dict([(table,succ)]))
        s = s +'第1代的流向（直接流向）：\n'+str(table)+' --> '+str(succ)+'\n'
        for j in range(back_deepth-1):
            if len(succ)>0:
                child,succ,dic_b = backward(g,succ,child)
                if sum([len(k) for k in dic_b.values()])>0:
                    s = s +'\n第'+str(j+2)+'代的流向：\n'
                de = []
                for key,value in dic_b.items():
                    if len(value)>0:
                        s = s +str(key)+' --> '+str(value)+'\n'
                    else:
                        de.append(key)
                for d in de:
                    dic_b.pop(d)
                dic.append(dic_b)
        s = s +'\n所有流向：\n'+str(child) +'\n'

    father.append(table);father.extend(child)
    sub_graph = g.subgraph(list(set(father)))
    #需要指定边的颜色，这里获取各个边的颜色，然后设置edge_color=co，可以对应上，至于它是怎么对应上的不清楚。
    co = []
    for (u,v,d) in sub_graph.edges(data=True):
        co.append(list(sub_graph.get_edge_data(u,v).values())[0])

    #s = s + '\033[0;32;47mAFTER_ALL:绿色\033[0m'+'\n';s = s + '\033[0;31;47mAFTER_SUCC：红色\033[0m' +'\n'
    plt.figure(figsize=(10,10))
    nx.draw_circular(sub_graph,with_labels=True, node_size=500,node_color = 'green',edge_color=co,font_size=8)
    plt.savefig("static/images/%s_%d_%d.png" %(table,for_deepth,back_deepth))
    #print s
    #plt.show()
    return s 

def get_job_relation(job_id,for_deepth,back_deepth):
    with open('job_networkx.pkl','rb') as f:
        DG = pickle.load(f)

    try:
        plt.switch_backend('agg')
        ret=sub_draw(DG,job_id,for_deepth,back_deepth)
    except Exception as e:
        ret=e

    return ret

if __name__ == '__main__':

	print get_job_relation('4655',3,2)

