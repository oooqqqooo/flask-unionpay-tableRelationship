# -*- coding: utf-8 -*- 
import networkx as nx
import pickle
import matplotlib.pyplot as plt 
import tree

#解析依赖和流向的关系，生成嵌套字典，如{'no surfacing': {0: 'no', 1: {'flippers': {0: 'no', 1: 'yes'}}, 3: 'maybe'}}，用于绘制树状图;
def parse(dic):
    num=0;d=[]
    for i in range(len(dic)):
        temp2={}
        for key,value in dic[i].items():
            temp={}
            if len(value)>0:
                for l in value:
                    temp[num] = l
                    num += 1
                temp2[key]=temp
        d.append(temp2)
    for j in range(len(d)-2,-1,-1):
        for key,value in d[j].items():
            for ke,va in value.items():
                try:
                    if va in d[j+1]:
                        d[j][key][ke]=dict([(va,d[j+1][va])])
                except TypeError:
                    pass
                
    return d[0]

def job_info(job):
    with open('job_info/tbl_sch_function_info.del') as f:
        index = 0
        for i in f.readlines():
            index += 1 
            if index==1:
                continue
            line =[j.strip(' ').strip('"') for j in i.strip().split(',')[:4]]
            if line[0]== job:
                return str(job)+": "+line[3]+"/"+line[2]+'\n'
        return ""

#向上寻找依赖关系
def forward(g,pred,father):
    newPred = [];dic={};pp=[]#pp 用于输出的顺序控制
    for i in pred:
        temp=[]
        if father.count(i)>1:
            pp.append(temp)
            continue
        for j in g.predecessors(i):
            #原本是只要之前出现过的job或table就不再加入，但是这样会出现问题，a->b和c,,而b->c，这种情况b->c就会被忽略，因此需要修改代码
            #if j not in father:
            newPred.append(j)
            temp.append(j)
        dic[i]=temp
        pp.append(temp)
    for i in newPred:
        father.append(i)
    return father,newPred,dic,pred,pp

#向下查看流向
def backward(g,succ,child):
    newSucc = [];dic={};ss = []
    for i in succ:
        temp=[]
        if child.count(i)>1:
            ss.append(temp)
            continue
        for j in g.successors(i):
            #if j not in child:
            child.append(j)
            newSucc.append(j)
            temp.append(j)
        dic[i]=temp
        ss.append(temp)
    return child,newSucc,dic,succ,ss

#根据传入的参数查看表或job的依赖和流向，并进行图展示
def sub_draw_for(g,table,for_deepth=0):
    s=""
    # pred是table的所有的父辈，succ是table的所有子辈
    pred =list(g.predecessors(table))
    for_deepth=int(for_deepth)
    #print type(pred)
    a = pred
    father = [i for i in pred]

    if for_deepth>0:
        dic_ff=[];dic_ff.append(dict([(table,pred)]))
        s = s + '\n第1辈的依赖（直接依赖）：\n'+str(table)+' <-- '+str(pred)+'\n'
        for i in range(for_deepth-1):
            if len(pred)>0:
                father,pred,dic_f,old_pred,pp = forward(g,pred,father)  #old_pred和pp用于输出顺序的控制
                if sum([len(k) for k in dic_f.values()])>0:  #没有依赖的字典中不一定为空，要判断字典中的value是不是都为空
                    s = s+'\n第'+str(i+2) +'辈的依赖：\n'
                de = []  #需要从字典中删除的元素
                for m in range(len(old_pred)):
                    if len(pp[m])>0:
                        s = s+str(old_pred[m])+' <-- '+str(pp[m])+'\n'
                for key,value in dic_f.items():
                    if len(value)==0:
                        de.append(key)
                for d in de:
                    dic_f.pop(d)
                dic_ff.append(dic_f)
        ##所有依赖去重
        father_list=[]
        for j in father:
            if j not in father_list:
                father_list.append(j)
        s = s + '\n所有依赖：\n'+str(father_list)+'\n\n\n'
        
        pa_f = parse(dic_ff)
        if pa_f:
            tree.createPlot(pa_f, "%s_for_%d" % (table,for_deepth))
    return s 

#根据传入的参数查看表或job的依赖和流向，并进行图展示
def sub_draw_back(g,table,back_deepth=0):
    s=""
    # pred是table的所有的父辈，succ是table的所有子辈
    succ = list(g.successors(table))
    back_deepth=int(back_deepth)
    #print type(pred)
    b=succ   
    child = [i for i in succ]
        
    if back_deepth>0:
        dic_bb=[];dic_bb.append(dict([(table,succ)]))  #dic_bb用于构建树状图的输入
        s = s +'第1代的流向（直接流向）：\n'+str(table)+' --> '+str(succ)+'\n'
        for j in range(back_deepth-1):
            if len(succ)>0:
                child,succ,dic_b,old_succ,ss = backward(g,succ,child)
                if sum([len(k) for k in dic_b.values()])>0:
                    s = s +'\n第'+str(j+2)+'代的流向：\n'
                de = []
                for m in range(len(old_succ)):
                    if len(ss[m])>0:
                        s = s+str(old_succ[m])+' --> '+str(ss[m])+'\n'
                for key,value in dic_b.items():
                    if len(value)==0:
                        de.append(key)
                for d in de:
                    dic_b.pop(d)
                dic_bb.append(dic_b)

        ##所有流向去重
        child_list=[]
        for j in child:
            if j not in child_list:
                child_list.append(j)
        s = s +'\n所有流向：\n'+str(child_list) +'\n'
        
        pa_b = parse(dic_bb)
        if pa_b:
            tree.createPlot(pa_b, "%s_back_%d" % (table,back_deepth))
    return s 

def get_job_relation(job_id,for_deepth,back_deepth):
    with open('job_networkx.pkl','rb') as f:
        DG = pickle.load(f)
    plt.switch_backend('agg')

#    try:
#        ret=job_info(job_id)+sub_draw_for(DG,job_id,for_deepth)+sub_draw_back(DG,job_id,back_deepth)
#    except Exception as e:
#        ret=e

    ret=job_info(job_id)+sub_draw_for(DG,job_id,for_deepth)+sub_draw_back(DG,job_id,back_deepth)

    return ret

if __name__ == '__main__':

	print get_job_relation('4656',5,3)

